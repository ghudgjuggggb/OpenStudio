#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Settings & Configuration for APK Terminal"""

import os
import json
from pathlib import Path

class Settings:
    CONFIG_DIR = Path.home() / ".config" / "apk_terminal"
    CONFIG_FILE = CONFIG_DIR / "config.json"
    
    DEFAULTS = {
        "ai_provider": "openai",       # openai | anthropic | ollama | gemini
        "ai_model": "gpt-4o",
        "api_key": "",
        "ollama_url": "http://localhost:11434",
        "work_dir": str(Path.home() / "apk_workspace"),
        "auto_install_tools": True,
        "language": "auto",            # auto | ru | en
        "max_tokens": 4096,
        "temperature": 0.7,
        "save_history": True,
        "history_file": str(Path.home() / ".config" / "apk_terminal" / "history.json"),
        "theme": "dark",               # dark | light | hacker
        "show_tool_output": True,
        "auto_backup_apk": True,
        "backup_dir": str(Path.home() / "apk_backups"),
        "sign_keystore": str(Path.home() / ".config" / "apk_terminal" / "debug.keystore"),
        "sign_key_alias": "androiddebugkey",
        "sign_key_pass": "android",
    }

    def __init__(self):
        self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self.data = self.load()

    def load(self):
        if self.CONFIG_FILE.exists():
            try:
                with open(self.CONFIG_FILE) as f:
                    saved = json.load(f)
                merged = {**self.DEFAULTS, **saved}
                return merged
            except:
                pass
        self.save(self.DEFAULTS)
        return dict(self.DEFAULTS)

    def save(self, data=None):
        if data is None:
            data = self.data
        with open(self.CONFIG_FILE, 'w') as f:
            json.dump(data, f, indent=2)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.set(key, value)
