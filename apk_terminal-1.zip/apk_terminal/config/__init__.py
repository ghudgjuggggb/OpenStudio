# APK Terminal Config
