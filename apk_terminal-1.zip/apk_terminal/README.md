# 🤖 APK Terminal — AI-Powered APK Editor for Termux

> Полноценный AI-ассистент для редактирования APK-файлов прямо в терминале Termux на Android

![Termux](https://img.shields.io/badge/Platform-Termux%20%7C%20Android-green)
![Python](https://img.shields.io/badge/Python-3.8+-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

---

## ✨ Возможности

| Функция | Описание |
|---------|----------|
| 🧠 **AI-агент** | Понимает команды на русском/английском языке |
| 📦 **APK редактирование** | Декомпиляция, сборка, подпись APK |
| 🔍 **Анализ APK** | Информация, манифест, ресурсы, smali |
| 📂 **Файловая система** | Полный доступ к файлам телефона |
| 🌐 **Интернет** | Скачивание файлов, HTTP запросы |
| 🛠 **Авто-установка** | Автоматически скачивает apktool, jadx и др. |
| 🔐 **Подпись APK** | Debug keystore из коробки |
| ☕ **Java деком** | Декомпиляция в Java через jadx |

---

## 📱 Установка на Termux

### Быстрая установка (рекомендуется)

```bash
# 1. Обновить Termux
pkg update && pkg upgrade -y

# 2. Установить git и python
pkg install git python -y

# 3. Клонировать репозиторий
git clone https://github.com/YOUR_USERNAME/apk-terminal.git
cd apk-terminal

# 4. Запустить установщик
bash install.sh

# 5. Перезагрузить PATH
source ~/.bashrc

# 6. Запустить!
apkt
```

### Ручная установка

```bash
# Зависимости Termux
pkg install python openjdk-21 aapt aapt2 zipalign apksigner curl wget git zip unzip android-tools -y

# Клонировать
git clone https://github.com/YOUR_USERNAME/apk-terminal.git ~/apk_terminal

# Запуск
cd ~/apk_terminal
python apk_terminal.py
```

---

## 🚀 Использование

### Запуск

```bash
apkt           # короткий алиас
apk-terminal   # полная команда
```

### Настройка AI

```bash
# Установить API ключ (OpenAI, Anthropic, Gemini)
/setkey sk-xxxxxxxxxxxxxxxx

# Или использовать локальный Ollama (бесплатно!)
# В config.json: ai_provider = "ollama", ai_model = "llama3"
```

### Команды APK

```bash
/decompile myapp.apk          # Декомпилировать APK
/compile myapp_decompiled     # Собрать обратно
/sign myapp_recompiled.apk    # Подписать APK
/info myapp.apk               # Информация об APK
/manifest myapp.apk           # Показать манифест
/install myapp_signed.apk     # Установить APK

# Через AI (просто напишите):
"декомпилируй myapp.apk и покажи все разрешения"
"найди в smali файлах строку 'api_key'"
"измени название приложения на 'MyApp'"
```

### Работа с файлами

```bash
/ls                           # Список файлов
/ls /storage/emulated/0       # Список файлов Android
/cd /sdcard/Download          # Перейти в папку
/cat file.txt                 # Прочитать файл
/find *.apk                   # Найти файлы
/download https://...         # Скачать файл
/shell ls -la                 # Выполнить команду
```

---

## 🤖 AI Провайдеры

| Провайдер | Настройка | Стоимость |
|-----------|-----------|-----------|
| **OpenAI** | `ai_provider = openai` | Платно |
| **Anthropic** | `ai_provider = anthropic` | Платно |
| **Google Gemini** | `ai_provider = gemini` | Бесплатный tier |
| **Ollama (local)** | `ai_provider = ollama` | 🆓 Бесплатно |

### Использование Ollama (локально, бесплатно)

```bash
# Установить Ollama на ПК/сервер
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull llama3

# В Termux настроить туннель или локальный запуск
# Затем в APK Terminal:
/config
# Изменить: ai_provider = ollama
#           ollama_url = http://192.168.1.x:11434
```

---

## 📁 Структура проекта

```
apk_terminal/
├── apk_terminal.py       # Точка входа
├── install.sh            # Установщик для Termux
├── README.md
├── config/
│   ├── __init__.py
│   └── settings.py       # Настройки
├── modules/
│   ├── __init__.py
│   ├── ui.py             # Цветной терминальный UI
│   ├── ai_agent.py       # AI-агент (мозг)
│   ├── apk_engine.py     # APK операции
│   ├── file_manager.py   # Файловый менеджер
│   ├── net_manager.py    # Сеть и загрузки
│   └── tool_manager.py   # Управление инструментами
└── logs/                 # Логи (создаётся автоматически)
```

---

## 🛠 Инструменты (устанавливаются автоматически)

- **apktool** — декомпиляция/сборка APK
- **jadx** — декомпиляция в Java
- **aapt/aapt2** — анализ APK ресурсов
- **zipalign** — оптимизация APK
- **apksigner** — подпись APK
- **adb** — установка APK (android-tools)
- **java** — среда выполнения

---

## ⚠️ Важно

- Приложение предназначено только для **легальных целей**: анализ своих приложений, разработка, исследование безопасности
- Редактирование чужих APK без разрешения нарушает авторские права
- Для работы на полную мощность нужен **root** или **Termux с разрешениями хранилища**

### Дать разрешение на хранилище

```bash
termux-setup-storage
```

---

## 📜 Лицензия

MIT License — используйте свободно!

---

## 🤝 Вклад

PR и Issues приветствуются! 

```bash
git clone https://github.com/YOUR_USERNAME/apk-terminal.git
cd apk-terminal
# Сделайте изменения
git commit -m "feat: your feature"
git push
```
