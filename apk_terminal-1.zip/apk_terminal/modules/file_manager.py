#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""File Manager - Full access to phone file system"""

import os
import shutil
import mimetypes
from pathlib import Path
from datetime import datetime


class FileManager:
    
    # Common Android paths
    ANDROID_PATHS = {
        "storage": "/storage/emulated/0",
        "downloads": "/storage/emulated/0/Download",
        "dcim": "/storage/emulated/0/DCIM",
        "documents": "/storage/emulated/0/Documents",
        "music": "/storage/emulated/0/Music",
        "apks": "/storage/emulated/0/Download",
        "home": str(Path.home()),
        "termux_home": str(Path.home()),
        "tmp": "/tmp",
        "sdcard": "/sdcard",
    }

    def __init__(self, ui):
        self.ui = ui
        self.current_dir = Path.cwd()
        self._history = []

    def ls(self, path=None, show_hidden=False, long=False):
        """List directory contents"""
        p = self._resolve(path or self.current_dir)
        
        if not p.exists():
            return {"success": False, "error": f"Path not found: {p}"}
        
        if p.is_file():
            return {"success": True, "type": "file", "path": str(p), "size": p.stat().st_size}

        try:
            items = []
            for item in sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
                if not show_hidden and item.name.startswith('.'):
                    continue
                
                try:
                    stat = item.stat()
                    entry = {
                        "name": item.name,
                        "type": "dir" if item.is_dir() else "file",
                        "size": stat.st_size if item.is_file() else None,
                        "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        "path": str(item),
                    }
                    if item.is_symlink():
                        entry["symlink"] = str(item.resolve())
                    items.append(entry)
                except PermissionError:
                    items.append({"name": item.name, "type": "unknown", "error": "permission denied"})

            return {
                "success": True,
                "path": str(p),
                "items": items,
                "dirs": sum(1 for i in items if i.get("type") == "dir"),
                "files": sum(1 for i in items if i.get("type") == "file"),
            }
        except PermissionError:
            return {"success": False, "error": f"Permission denied: {p}"}

    def cd(self, path):
        """Change current directory"""
        p = self._resolve(path)
        if not p.exists():
            return {"success": False, "error": f"Path not found: {p}"}
        if not p.is_dir():
            return {"success": False, "error": f"Not a directory: {p}"}
        
        self._history.append(str(self.current_dir))
        self.current_dir = p
        os.chdir(p)
        return {"success": True, "cwd": str(p)}

    def pwd(self):
        return str(self.current_dir)

    def read_file(self, path, max_size_kb=500):
        """Read file content"""
        p = self._resolve(path)
        if not p.exists():
            return {"success": False, "error": f"File not found: {p}"}
        if not p.is_file():
            return {"success": False, "error": f"Not a file: {p}"}

        size_kb = p.stat().st_size / 1024
        if size_kb > max_size_kb:
            return {
                "success": False,
                "error": f"File too large ({size_kb:.0f}KB). Max: {max_size_kb}KB",
                "size_kb": size_kb
            }

        # Detect type
        mime, _ = mimetypes.guess_type(str(p))
        
        # Binary check
        if mime and not (mime.startswith('text') or mime in ['application/json', 'application/xml', 'application/javascript']):
            return {
                "success": False,
                "error": f"Binary file ({mime}). Use specific tools to handle.",
                "mime": mime
            }

        try:
            content = p.read_text(errors='replace')
            return {"success": True, "content": content, "path": str(p), "size_kb": size_kb}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def write_file(self, path, content, backup=True):
        """Write content to file"""
        p = self._resolve(path)
        
        if backup and p.exists():
            bak = str(p) + ".bak"
            shutil.copy2(p, bak)

        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            return {"success": True, "path": str(p), "size": len(content)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def find(self, name_pattern, start_dir=None, file_type=None, max_results=100):
        """Find files by name pattern"""
        start = self._resolve(start_dir) if start_dir else self.current_dir
        results = []

        try:
            for p in start.rglob(f"*{name_pattern}*"):
                if len(results) >= max_results:
                    break
                if file_type == "f" and not p.is_file():
                    continue
                if file_type == "d" and not p.is_dir():
                    continue
                results.append(str(p))
        except PermissionError:
            pass
        
        return {"success": True, "results": results, "count": len(results)}

    def copy(self, src, dst):
        """Copy file or directory"""
        s = self._resolve(src)
        d = self._resolve(dst)
        try:
            if s.is_dir():
                shutil.copytree(s, d)
            else:
                d.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(s, d)
            return {"success": True, "from": str(s), "to": str(d)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def move(self, src, dst):
        """Move file or directory"""
        s = self._resolve(src)
        d = self._resolve(dst)
        try:
            shutil.move(str(s), str(d))
            return {"success": True, "from": str(s), "to": str(d)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete(self, path, recursive=False):
        """Delete file or directory"""
        p = self._resolve(path)
        try:
            if p.is_dir():
                if recursive:
                    shutil.rmtree(p)
                else:
                    p.rmdir()
            else:
                p.unlink()
            return {"success": True, "deleted": str(p)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def mkdir(self, path):
        """Create directory"""
        p = self._resolve(path)
        try:
            p.mkdir(parents=True, exist_ok=True)
            return {"success": True, "path": str(p)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def stat(self, path):
        """Get file/directory info"""
        p = self._resolve(path)
        try:
            s = p.stat()
            return {
                "success": True,
                "path": str(p),
                "exists": True,
                "is_file": p.is_file(),
                "is_dir": p.is_dir(),
                "size": s.st_size,
                "size_kb": round(s.st_size / 1024, 2),
                "modified": datetime.fromtimestamp(s.st_mtime).isoformat(),
                "created": datetime.fromtimestamp(s.st_ctime).isoformat(),
                "permissions": oct(s.st_mode)[-3:],
            }
        except FileNotFoundError:
            return {"success": True, "path": str(p), "exists": False}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def search_in_files(self, pattern, directory=None, file_ext=None, max_results=50):
        """Search for text pattern in files"""
        start = self._resolve(directory) if directory else self.current_dir
        results = []

        glob_pattern = f"**/*.{file_ext}" if file_ext else "**/*"
        
        try:
            for p in start.glob(glob_pattern):
                if len(results) >= max_results:
                    break
                if not p.is_file():
                    continue
                try:
                    if p.stat().st_size > 5 * 1024 * 1024:  # Skip >5MB
                        continue
                    content = p.read_text(errors='ignore')
                    if pattern.lower() in content.lower():
                        lines = []
                        for i, line in enumerate(content.split('\n'), 1):
                            if pattern.lower() in line.lower():
                                lines.append({"line": i, "content": line.strip()})
                                if len(lines) >= 5:
                                    break
                        results.append({"file": str(p), "matches": lines})
                except:
                    pass
        except PermissionError:
            pass

        return {"success": True, "results": results, "count": len(results), "pattern": pattern}

    def get_disk_info(self):
        """Get storage information"""
        info = {}
        try:
            for path_name, path in self.ANDROID_PATHS.items():
                if os.path.exists(path):
                    try:
                        usage = shutil.disk_usage(path)
                        info[path_name] = {
                            "path": path,
                            "total_gb": round(usage.total / 1e9, 2),
                            "used_gb": round(usage.used / 1e9, 2),
                            "free_gb": round(usage.free / 1e9, 2),
                            "percent_used": round(usage.used / usage.total * 100, 1)
                        }
                    except:
                        pass
        except:
            pass
        return {"success": True, "storage": info}

    def _resolve(self, path):
        """Resolve path (handle ~, relative, shortcuts)"""
        p = str(path)
        
        # Handle shortcuts
        for name, real in self.ANDROID_PATHS.items():
            if p == name or p == f"@{name}":
                return Path(real)
        
        p_obj = Path(p).expanduser()
        if p_obj.is_absolute():
            return p_obj
        return (self.current_dir / p_obj).resolve()

    def format_ls_output(self, ls_result):
        """Format ls result for display"""
        if not ls_result["success"]:
            return f"Error: {ls_result['error']}"
        
        items = ls_result.get("items", [])
        lines = [f"\n📂 {ls_result['path']}\n"]
        
        for item in items:
            if item.get("type") == "dir":
                icon = "📁"
                name = item["name"] + "/"
            elif item["name"].endswith(".apk"):
                icon = "📦"
                name = item["name"]
            elif item["name"].endswith((".py", ".sh", ".js")):
                icon = "📜"
                name = item["name"]
            elif item["name"].endswith((".jpg", ".png", ".gif")):
                icon = "🖼 "
                name = item["name"]
            else:
                icon = "📄"
                name = item["name"]
            
            size = ""
            if item.get("size") is not None:
                size_val = item["size"]
                if size_val > 1024*1024:
                    size = f"{size_val/1024/1024:.1f}M"
                elif size_val > 1024:
                    size = f"{size_val/1024:.1f}K"
                else:
                    size = f"{size_val}B"
            
            mod = item.get("modified", "")
            lines.append(f"  {icon}  {name:<40} {size:>8}  {mod}")
        
        lines.append(f"\n  {ls_result.get('dirs', 0)} dirs, {ls_result.get('files', 0)} files")
        return "\n".join(lines)
