#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI Agent - The brain of APK Terminal"""

import os
import json
import re
from pathlib import Path
from datetime import datetime


SYSTEM_PROMPT = """You are APK Terminal - an expert AI assistant running inside Termux on Android. You help users edit, patch, and analyze Android APK files with full expertise.

You have access to these tools:
- APK tools: apktool (decompile/compile), jadx (Java decompile), aapt/aapt2 (APK info), zipalign, apksigner
- File system: full access to phone storage (read/write/delete/find/search)
- Internet: download files, fetch URLs, search for APKs
- Shell: execute any terminal command

When the user asks you to do something:
1. Analyze what needs to be done
2. Respond with a JSON action plan using this format:

{
  "thoughts": "brief explanation of what you'll do",
  "actions": [
    {"type": "shell", "cmd": "command to run", "desc": "what this does"},
    {"type": "apk_decompile", "apk": "path/to/apk", "out": "optional output dir"},
    {"type": "apk_compile", "dir": "path/to/src", "out": "optional output"},
    {"type": "apk_sign", "apk": "path", "out": "optional"},
    {"type": "apk_info", "apk": "path"},
    {"type": "apk_manifest", "path": "apk or dir"},
    {"type": "apk_install", "apk": "path"},
    {"type": "apk_patch", "file": "path", "old": "old text", "new": "new text"},
    {"type": "apk_smali", "dir": "path", "search": "optional term"},
    {"type": "apk_resources", "dir": "path"},
    {"type": "apk_java", "apk": "path"},
    {"type": "file_read", "path": "file path"},
    {"type": "file_write", "path": "path", "content": "content to write"},
    {"type": "file_ls", "path": "directory", "hidden": false},
    {"type": "file_find", "pattern": "*.apk", "dir": "optional", "type": "f or d"},
    {"type": "file_search", "pattern": "text to find", "dir": "optional", "ext": "smali"},
    {"type": "file_mkdir", "path": "path"},
    {"type": "file_delete", "path": "path"},
    {"type": "file_copy", "src": "src", "dst": "dst"},
    {"type": "file_move", "src": "src", "dst": "dst"},
    {"type": "net_download", "url": "url", "out": "optional path"},
    {"type": "net_fetch", "url": "url"},
    {"type": "tool_install", "tools": ["apktool", "jadx"]},
    {"type": "tools_status"},
    {"type": "install_all_tools"}
  ],
  "message": "Message to show user after executing all actions"
}

Always respond with valid JSON. No markdown, no explanations outside JSON.

Rules:
- Be proactive: if user says "edit manifest", decompile first if needed
- If a tool is missing, offer to install it
- Always explain what you're doing in "thoughts"
- Keep "message" helpful and concise
- For APK editing workflows: decompile → edit → compile → sign
- When patching, always suggest creating backup first
- Support Russian language - respond in same language as user
- If user speaks Russian, thoughts and message should be in Russian too
"""

class AIAgent:
    
    def __init__(self, ui, tool_manager, file_manager, apk_engine, net_manager, settings):
        self.ui = ui
        self.tm = tool_manager
        self.fm = file_manager
        self.apk = apk_engine
        self.net = net_manager
        self.settings = settings
        self.history = []
        self.running = True
        self._load_history()

    def _load_history(self):
        h_file = Path(self.settings.get("history_file", ""))
        if h_file and h_file.exists():
            try:
                self.history = json.loads(h_file.read_text())[-50:]  # last 50
            except:
                self.history = []

    def _save_history(self):
        if not self.settings.get("save_history", True):
            return
        h_file = Path(self.settings.get("history_file", ""))
        if h_file:
            h_file.parent.mkdir(parents=True, exist_ok=True)
            h_file.write_text(json.dumps(self.history[-100:], ensure_ascii=False, indent=2))

    def run(self):
        """Main interaction loop"""
        while self.running:
            try:
                user_input = self.ui.prompt()
                
                if not user_input:
                    continue

                # Built-in commands
                result = self._handle_command(user_input)
                if result == "HANDLED":
                    continue
                elif result == "EXIT":
                    break

                # AI processing
                self._process_with_ai(user_input)

            except KeyboardInterrupt:
                print("\n")
                self.ui.info("Use /exit to quit or press Ctrl+C again to force exit.")
                try:
                    input()
                except KeyboardInterrupt:
                    break

        self._save_history()
        print("\n👋 Goodbye!\n")

    def _handle_command(self, cmd):
        """Handle built-in commands"""
        parts = cmd.strip().split(None, 2)
        command = parts[0].lower() if parts else ""

        if command in ('/exit', '/quit', 'exit', 'quit'):
            return "EXIT"

        elif command in ('/help', 'help', '?'):
            self.ui.print_help()
            return "HANDLED"

        elif command == '/clear':
            self.ui.clear_screen()
            self.ui.print_banner()
            return "HANDLED"

        elif command == '/tools':
            status = self.tm.get_all_status()
            self.ui.print_tools_table(status)
            return "HANDLED"

        elif command == '/install-tools':
            self.tm.check_and_install_all()
            return "HANDLED"

        elif command == '/ls':
            path = parts[1] if len(parts) > 1 else None
            result = self.fm.ls(path)
            print(self.fm.format_ls_output(result))
            return "HANDLED"

        elif command == '/cd':
            if len(parts) < 2:
                self.ui.error("Usage: /cd <path>")
                return "HANDLED"
            result = self.fm.cd(parts[1])
            if result["success"]:
                self.ui.success(f"📂 {result['cwd']}")
            else:
                self.ui.error(result["error"])
            return "HANDLED"

        elif command == '/pwd':
            print(f"📂 {self.fm.pwd()}")
            return "HANDLED"

        elif command == '/cat':
            if len(parts) < 2:
                self.ui.error("Usage: /cat <file>")
                return "HANDLED"
            result = self.fm.read_file(parts[1])
            if result["success"]:
                print(f"\n{result['content']}\n")
            else:
                self.ui.error(result["error"])
            return "HANDLED"

        elif command == '/shell':
            if len(parts) < 2:
                self.ui.error("Usage: /shell <command>")
                return "HANDLED"
            shell_cmd = cmd[len('/shell'):].strip()
            result = self.tm.run_shell(shell_cmd)
            self.ui.tool_output(f"shell: {shell_cmd}", result["output"], result["success"])
            return "HANDLED"

        elif command == '/download':
            if len(parts) < 2:
                self.ui.error("Usage: /download <url> [output_path]")
                return "HANDLED"
            url = parts[1]
            out = parts[2] if len(parts) > 2 else None
            result = self.net.download(url, out)
            if result["success"]:
                self.ui.success(f"Downloaded: {result['path']}")
            else:
                self.ui.error(result["error"])
            return "HANDLED"

        elif command == '/config':
            self._show_config()
            return "HANDLED"

        elif command == '/setkey':
            if len(parts) < 2:
                self.ui.error("Usage: /setkey <api_key>")
                return "HANDLED"
            self.settings.set("api_key", parts[1])
            self.ui.success("API key saved!")
            return "HANDLED"

        elif command == '/model':
            if len(parts) < 2:
                self.ui.info(f"Current model: {self.settings.get('ai_model')}")
                return "HANDLED"
            self.settings.set("ai_model", parts[1])
            self.ui.success(f"Model set to: {parts[1]}")
            return "HANDLED"

        elif command == '/history':
            self._show_history()
            return "HANDLED"

        elif command in ('/decompile', '/apk-decompile'):
            if len(parts) < 2:
                self.ui.error("Usage: /decompile <apk_path>")
                return "HANDLED"
            result = self.apk.decompile(parts[1])
            if result["success"]:
                self.ui.success(f"Decompiled to: {result['out_dir']}")
            else:
                self.ui.error(result.get("error", "Decompile failed"))
            return "HANDLED"

        elif command in ('/compile', '/apk-compile'):
            if len(parts) < 2:
                self.ui.error("Usage: /compile <directory>")
                return "HANDLED"
            result = self.apk.compile(parts[1])
            if result["success"]:
                self.ui.success(f"Compiled: {result['apk_path']}")
            else:
                self.ui.error(result.get("error", "Compile failed"))
            return "HANDLED"

        elif command in ('/sign', '/apk-sign'):
            if len(parts) < 2:
                self.ui.error("Usage: /sign <apk_path>")
                return "HANDLED"
            result = self.apk.sign(parts[1])
            if result["success"]:
                self.ui.success(f"Signed: {result['signed_apk']}")
            else:
                self.ui.error(result.get("error", "Sign failed"))
            return "HANDLED"

        elif command in ('/info', '/apk-info'):
            if len(parts) < 2:
                self.ui.error("Usage: /info <apk_path>")
                return "HANDLED"
            result = self.apk.get_info(parts[1])
            if result["success"]:
                self._print_apk_info(result["info"])
            else:
                self.ui.error(result.get("error", "Failed"))
            return "HANDLED"

        elif command in ('/manifest',):
            if len(parts) < 2:
                self.ui.error("Usage: /manifest <apk_or_dir>")
                return "HANDLED"
            result = self.apk.read_manifest(parts[1])
            if result["success"]:
                print(f"\n{result['content'][:5000]}\n")
            else:
                self.ui.error(result["error"])
            return "HANDLED"

        elif command in ('/install', '/apk-install'):
            if len(parts) < 2:
                self.ui.error("Usage: /install <apk_path>")
                return "HANDLED"
            result = self.apk.install_apk(parts[1])
            if result["success"]:
                self.ui.success("APK installed!")
            else:
                self.ui.error(result.get("output", "Install failed"))
            return "HANDLED"

        elif command == '/find':
            if len(parts) < 2:
                self.ui.error("Usage: /find <pattern>")
                return "HANDLED"
            result = self.fm.find(parts[1])
            for f in result["results"][:30]:
                print(f"  {f}")
            self.ui.info(f"Found {result['count']} matches")
            return "HANDLED"

        return None  # Not a command, process with AI

    def _process_with_ai(self, user_input):
        """Send to AI and execute returned actions"""
        # Add context to message
        context = f"[CWD: {self.fm.pwd()}] [Time: {datetime.now().strftime('%H:%M')}]"
        full_input = f"{user_input}\n{context}"

        self.history.append({"role": "user", "content": full_input})

        # Try to get AI response
        ai_response = self._call_ai()
        
        if not ai_response:
            # Fallback: handle simple requests locally
            self._local_fallback(user_input)
            return

        self.history.append({"role": "assistant", "content": ai_response})

        # Parse and execute
        try:
            parsed = self._parse_ai_response(ai_response)
            if parsed:
                self._execute_plan(parsed)
            else:
                # Plain text response
                self.ui.ai_msg(ai_response)
        except Exception as e:
            self.ui.ai_msg(ai_response)

    def _call_ai(self):
        """Call configured AI provider"""
        api_key = self.settings.get("api_key", "")
        provider = self.settings.get("ai_provider", "openai")
        model = self.settings.get("ai_model", "gpt-4o")

        if not api_key and provider != "ollama":
            self.ui.warn("No API key configured. Use /setkey <key> to set one.")
            self.ui.warn("Or set provider to ollama: /config → ai_provider = ollama")
            return None

        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.history[-20:]

        try:
            if provider == "openai":
                result = self.net.fetch(
                    "https://api.openai.com/v1/chat/completions",
                    method="POST",
                    json_data={
                        "model": model,
                        "messages": messages,
                        "max_tokens": self.settings.get("max_tokens", 4096),
                        "temperature": self.settings.get("temperature", 0.7),
                    },
                    headers={"Authorization": f"Bearer {api_key}"}
                )
                if result["success"] and result.get("json"):
                    return result["json"]["choices"][0]["message"]["content"]

            elif provider == "anthropic":
                result = self.net.fetch(
                    "https://api.anthropic.com/v1/messages",
                    method="POST",
                    json_data={
                        "model": model or "claude-opus-4-5",
                        "max_tokens": self.settings.get("max_tokens", 4096),
                        "system": SYSTEM_PROMPT,
                        "messages": [m for m in self.history[-20:] if m["role"] in ("user", "assistant")],
                    },
                    headers={
                        "x-api-key": api_key,
                        "anthropic-version": "2023-06-01",
                    }
                )
                if result["success"] and result.get("json"):
                    content = result["json"].get("content", [])
                    text_blocks = [b["text"] for b in content if b.get("type") == "text"]
                    return "\n".join(text_blocks)

            elif provider == "gemini":
                result = self.net.fetch(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{model or 'gemini-pro'}:generateContent?key={api_key}",
                    method="POST",
                    json_data={
                        "contents": [{"parts": [{"text": m["content"]}], "role": "user" if m["role"] == "user" else "model"}
                                     for m in self.history[-20:]],
                        "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
                    }
                )
                if result["success"] and result.get("json"):
                    try:
                        return result["json"]["candidates"][0]["content"]["parts"][0]["text"]
                    except:
                        pass

            elif provider == "ollama":
                full_prompt = SYSTEM_PROMPT + "\n\nConversation:\n"
                for m in self.history[-10:]:
                    full_prompt += f"{m['role'].upper()}: {m['content']}\n"
                full_prompt += "ASSISTANT:"
                
                result = self.net.call_ollama(
                    full_prompt,
                    model=model or "llama3",
                    url=self.settings.get("ollama_url", "http://localhost:11434")
                )
                if result["success"]:
                    return result["text"]

        except Exception as e:
            self.ui.error(f"AI call failed: {e}")

        return None

    def _parse_ai_response(self, response):
        """Parse JSON from AI response"""
        # Try direct parse
        text = response.strip()
        
        # Extract JSON from code blocks
        json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
        if json_match:
            text = json_match.group(1)
        
        # Find JSON object
        start = text.find('{')
        if start == -1:
            return None
        
        # Try to find matching closing brace
        depth = 0
        end = -1
        for i, c in enumerate(text[start:], start):
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
        
        if end == -1:
            return None

        json_str = text[start:end]
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            # Try to fix common issues
            json_str = re.sub(r',\s*}', '}', json_str)
            json_str = re.sub(r',\s*]', ']', json_str)
            try:
                return json.loads(json_str)
            except:
                return None

    def _execute_plan(self, plan):
        """Execute AI action plan"""
        thoughts = plan.get("thoughts", "")
        actions = plan.get("actions", [])
        message = plan.get("message", "")

        if thoughts:
            self.ui.info(f"💭 {thoughts}")

        results = []
        
        for action in actions:
            action_type = action.get("type", "")
            result = self._execute_action(action_type, action)
            results.append(result)

        if message:
            self.ui.ai_msg(message)
        
        return results

    def _execute_action(self, action_type, params):
        """Execute a single action"""
        self.ui.info(f"⚡ {action_type}...")
        
        try:
            if action_type == "shell":
                cmd = params.get("cmd", "")
                desc = params.get("desc", cmd)
                result = self.tm.run_shell(cmd, cwd=self.fm.pwd())
                self.ui.tool_output(desc, result["output"], result["success"])
                return result

            elif action_type == "apk_decompile":
                apk = params.get("apk", "")
                out = params.get("out")
                result = self.apk.decompile(apk, out)
                if result["success"]:
                    self.ui.success(f"Decompiled to: {result['out_dir']}")
                else:
                    self.ui.error(result.get("error", "Failed"))
                return result

            elif action_type == "apk_compile":
                d = params.get("dir", "")
                out = params.get("out")
                result = self.apk.compile(d, out)
                if result["success"]:
                    self.ui.success(f"Compiled: {result['apk_path']}")
                else:
                    self.ui.error(result.get("error", "Failed"))
                return result

            elif action_type == "apk_sign":
                apk = params.get("apk", "")
                out = params.get("out")
                result = self.apk.sign(apk, out)
                if result["success"]:
                    self.ui.success(f"Signed: {result['signed_apk']}")
                else:
                    self.ui.error(result.get("error", "Failed"))
                return result

            elif action_type == "apk_info":
                apk = params.get("apk", "")
                result = self.apk.get_info(apk)
                if result["success"]:
                    self._print_apk_info(result["info"])
                return result

            elif action_type == "apk_manifest":
                path = params.get("path", "")
                result = self.apk.read_manifest(path)
                if result["success"]:
                    print(f"\n{result['content'][:5000]}\n")
                return result

            elif action_type == "apk_install":
                apk = params.get("apk", "")
                result = self.apk.install_apk(apk)
                if result["success"]:
                    self.ui.success("APK installed!")
                else:
                    self.ui.error(result.get("output", "Failed"))
                return result

            elif action_type == "apk_patch":
                file_path = params.get("file", "")
                old = params.get("old", "")
                new = params.get("new", "")
                result = self.apk.patch_file(file_path, old, new)
                if result["success"]:
                    self.ui.success(f"Patched {result.get('replaced', 0)} occurrences")
                else:
                    self.ui.error(result.get("error", "Failed"))
                return result

            elif action_type == "apk_smali":
                d = params.get("dir", "")
                search = params.get("search")
                result = self.apk.find_smali(d, search)
                if result["success"]:
                    for f in result["files"][:20]:
                        print(f"  {f}")
                    self.ui.info(f"Found {result['count']} smali files")
                return result

            elif action_type == "apk_resources":
                d = params.get("dir", "")
                result = self.apk.list_resources(d)
                if result["success"]:
                    for folder, files in result["resources"].items():
                        print(f"  📁 {folder}/: {', '.join(files[:5])}")
                return result

            elif action_type == "apk_java":
                apk = params.get("apk", "")
                result = self.apk.decompile_java(apk)
                if result["success"]:
                    self.ui.success(f"Java decompiled to: {result['out_dir']}")
                else:
                    self.ui.error(result.get("error", "Failed"))
                return result

            elif action_type == "file_read":
                path = params.get("path", "")
                result = self.fm.read_file(path)
                if result["success"]:
                    print(f"\n{'─'*50}\n{result['content'][:5000]}\n{'─'*50}\n")
                else:
                    self.ui.error(result["error"])
                return result

            elif action_type == "file_write":
                path = params.get("path", "")
                content = params.get("content", "")
                result = self.fm.write_file(path, content)
                if result["success"]:
                    self.ui.success(f"Written: {path}")
                else:
                    self.ui.error(result["error"])
                return result

            elif action_type == "file_ls":
                path = params.get("path")
                hidden = params.get("hidden", False)
                result = self.fm.ls(path, hidden)
                print(self.fm.format_ls_output(result))
                return result

            elif action_type == "file_find":
                pattern = params.get("pattern", "")
                d = params.get("dir")
                ftype = params.get("type")
                result = self.fm.find(pattern, d, ftype)
                for f in result["results"][:30]:
                    print(f"  {f}")
                self.ui.info(f"Found: {result['count']}")
                return result

            elif action_type == "file_search":
                pattern = params.get("pattern", "")
                d = params.get("dir")
                ext = params.get("ext")
                result = self.fm.search_in_files(pattern, d, ext)
                for r in result["results"][:20]:
                    print(f"\n  📄 {r['file']}")
                    for m in r["matches"]:
                        print(f"    L{m['line']}: {m['content']}")
                return result

            elif action_type == "file_mkdir":
                path = params.get("path", "")
                result = self.fm.mkdir(path)
                if result["success"]:
                    self.ui.success(f"Created: {path}")
                return result

            elif action_type == "file_delete":
                path = params.get("path", "")
                recursive = params.get("recursive", False)
                result = self.fm.delete(path, recursive)
                if result["success"]:
                    self.ui.success(f"Deleted: {path}")
                else:
                    self.ui.error(result["error"])
                return result

            elif action_type == "file_copy":
                result = self.fm.copy(params.get("src", ""), params.get("dst", ""))
                if result["success"]:
                    self.ui.success(f"Copied: {result['from']} → {result['to']}")
                else:
                    self.ui.error(result["error"])
                return result

            elif action_type == "file_move":
                result = self.fm.move(params.get("src", ""), params.get("dst", ""))
                if result["success"]:
                    self.ui.success(f"Moved: {result['from']} → {result['to']}")
                else:
                    self.ui.error(result["error"])
                return result

            elif action_type == "net_download":
                url = params.get("url", "")
                out = params.get("out")
                result = self.net.download(url, out)
                if result["success"]:
                    self.ui.success(f"Downloaded: {result['path']}")
                else:
                    self.ui.error(result["error"])
                return result

            elif action_type == "net_fetch":
                url = params.get("url", "")
                result = self.net.fetch(url)
                if result["success"]:
                    text = result.get("text", "")
                    print(f"\n{text[:3000]}\n")
                else:
                    self.ui.error(result["error"])
                return result

            elif action_type == "tool_install":
                tools = params.get("tools", [])
                in_termux = os.path.exists('/data/data/com.termux')
                for tool in tools:
                    self.tm.install_tool(tool, in_termux)
                return {"success": True}

            elif action_type == "tools_status":
                status = self.tm.get_all_status()
                self.ui.print_tools_table(status)
                return {"success": True, "status": status}

            elif action_type == "install_all_tools":
                self.tm.check_and_install_all()
                return {"success": True}

            else:
                self.ui.warn(f"Unknown action: {action_type}")
                return {"success": False, "error": f"Unknown action: {action_type}"}

        except Exception as e:
            self.ui.error(f"Action {action_type} failed: {e}")
            return {"success": False, "error": str(e)}

    def _local_fallback(self, user_input):
        """Handle common requests without AI"""
        inp = user_input.lower()
        
        if any(w in inp for w in ['привет', 'hello', 'hi', 'help', 'помощь']):
            self.ui.ai_msg("Привет! Я APK Terminal — AI-ассистент для редактирования APK-файлов.\n"
                          "Введите /help для списка команд, или просто опишите что хотите сделать!\n"
                          "Для работы AI укажите API ключ командой: /setkey <ваш_ключ>")
        
        elif any(w in inp for w in ['tools', 'инструменты', 'статус']):
            status = self.tm.get_all_status()
            self.ui.print_tools_table(status)
        
        elif any(w in inp for w in ['ls', 'files', 'файлы', 'список']):
            result = self.fm.ls()
            print(self.fm.format_ls_output(result))
        
        else:
            self.ui.warn("API ключ не настроен. AI недоступен.")
            self.ui.info("Установите ключ: /setkey <api_key>")
            self.ui.info("Или используйте команды: /help")

    def _print_apk_info(self, info):
        """Pretty print APK info"""
        self.ui.print_separator()
        print(f"\n📦 APK Info: {info.get('file', '')}\n")
        print(f"  Size: {info.get('size_mb', 0)} MB")
        print(f"  Files: {info.get('files_count', '?')}")
        print(f"  DEX files: {info.get('dex_count', '?')}")
        print(f"  Has Kotlin: {info.get('has_kotlin', False)}")
        
        if info.get("has_libs"):
            print(f"  Native libs: {', '.join(info.get('libs', []))}")
        
        aapt = info.get("aapt", {})
        if aapt:
            print(f"\n  Package: {aapt.get('package_line', 'unknown')}")
            print(f"  Label: {aapt.get('label', '?')}")
            print(f"  Min SDK: {aapt.get('min_sdk', '?')}")
            print(f"  Target SDK: {aapt.get('target_sdk', '?')}")
            perms = aapt.get("permissions", [])
            if perms:
                print(f"\n  Permissions ({len(perms)}):")
                for p in perms[:15]:
                    print(f"    • {p}")
                if len(perms) > 15:
                    print(f"    ... and {len(perms)-15} more")
        
        self.ui.print_separator()

    def _show_config(self):
        """Show configuration"""
        self.ui.print_separator()
        print(f"\n⚙️  Configuration:\n")
        for key, val in self.settings.data.items():
            if 'key' in key.lower() or 'pass' in key.lower():
                val_display = '***' if val else '(not set)'
            else:
                val_display = str(val)
            print(f"  {key:<25} = {val_display}")
        print(f"\n  Edit: {self.settings.CONFIG_FILE}\n")
        self.ui.print_separator()

    def _show_history(self):
        """Show conversation history"""
        self.ui.print_separator()
        print(f"\n💬 Conversation History ({len(self.history)} messages):\n")
        for msg in self.history[-10:]:
            role = "🤖 AI" if msg["role"] == "assistant" else "👤 You"
            content = msg["content"][:200] + "..." if len(msg["content"]) > 200 else msg["content"]
            print(f"  {role}: {content}\n")
        self.ui.print_separator()
