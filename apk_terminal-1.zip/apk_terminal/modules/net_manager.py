#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Network Manager - Internet access and downloads"""

import os
import json
import urllib.request
import urllib.parse
import urllib.error
import ssl
import socket
from pathlib import Path
from datetime import datetime


class NetManager:
    
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }

    def __init__(self, ui):
        self.ui = ui
        self.ssl_ctx = ssl.create_default_context()
        self.ssl_ctx.check_hostname = False
        self.ssl_ctx.verify_mode = ssl.CERT_NONE
        self.download_dir = Path.home() / "Downloads"
        self.download_dir.mkdir(exist_ok=True)

    def check_connection(self):
        """Check internet connectivity"""
        test_hosts = ["8.8.8.8", "1.1.1.1", "google.com"]
        for host in test_hosts:
            try:
                socket.setdefaulttimeout(3)
                socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, 53))
                return {"success": True, "connected": True, "host": host}
            except socket.error:
                pass
        return {"success": True, "connected": False}

    def download(self, url, out_path=None, show_progress=True):
        """Download file from URL"""
        url = url.strip()
        
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        # Determine filename
        if out_path is None:
            filename = url.split('/')[-1].split('?')[0] or "download"
            if not filename:
                filename = "download"
            out_path = self.download_dir / filename
        
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)

        self.ui.info(f"Downloading: {url}")
        self.ui.info(f"Saving to: {out_path}")

        try:
            req = urllib.request.Request(url, headers=self.HEADERS)
            
            with urllib.request.urlopen(req, context=self.ssl_ctx, timeout=120) as response:
                total = int(response.headers.get('Content-Length', 0))
                downloaded = 0
                chunk_size = 65536  # 64KB

                with open(out_path, 'wb') as f:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        if show_progress and total > 0:
                            pct = downloaded / total * 100
                            mb = downloaded / 1024 / 1024
                            total_mb = total / 1024 / 1024
                            print(f"\r  📥 {pct:.1f}% ({mb:.1f}/{total_mb:.1f} MB)", end='', flush=True)

            if show_progress and total > 0:
                print()  # newline after progress

            size = out_path.stat().st_size
            self.ui.success(f"Downloaded: {out_path} ({size/1024:.1f} KB)")
            return {
                "success": True,
                "path": str(out_path),
                "size": size,
                "size_kb": round(size/1024, 1),
                "url": url
            }

        except urllib.error.HTTPError as e:
            return {"success": False, "error": f"HTTP {e.code}: {e.reason}", "url": url}
        except urllib.error.URLError as e:
            return {"success": False, "error": f"URL error: {e.reason}", "url": url}
        except Exception as e:
            return {"success": False, "error": str(e), "url": url}

    def fetch(self, url, method="GET", data=None, headers=None, json_data=None):
        """Fetch URL and return content"""
        url = url.strip()
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        req_headers = {**self.HEADERS}
        if headers:
            req_headers.update(headers)

        body = None
        if json_data:
            body = json.dumps(json_data).encode('utf-8')
            req_headers['Content-Type'] = 'application/json'
        elif data:
            if isinstance(data, dict):
                body = urllib.parse.urlencode(data).encode('utf-8')
                req_headers['Content-Type'] = 'application/x-www-form-urlencoded'
            else:
                body = data.encode('utf-8') if isinstance(data, str) else data

        try:
            req = urllib.request.Request(url, data=body, headers=req_headers, method=method)
            
            with urllib.request.urlopen(req, context=self.ssl_ctx, timeout=30) as response:
                content = response.read()
                content_type = response.headers.get('Content-Type', '')
                status = response.status
                
                # Try to decode
                text = None
                if 'text' in content_type or 'json' in content_type or 'xml' in content_type:
                    try:
                        text = content.decode('utf-8', errors='replace')
                    except:
                        text = content.decode('latin-1', errors='replace')

                result = {
                    "success": True,
                    "status": status,
                    "content_type": content_type,
                    "url": url,
                }
                
                if text:
                    result["text"] = text
                    # Try JSON parse
                    if 'json' in content_type:
                        try:
                            result["json"] = json.loads(text)
                        except:
                            pass
                else:
                    result["bytes"] = len(content)

                return result

        except urllib.error.HTTPError as e:
            return {"success": False, "status": e.code, "error": f"HTTP {e.code}: {e.reason}", "url": url}
        except Exception as e:
            return {"success": False, "error": str(e), "url": url}

    def search_apk(self, query):
        """Search for APK on common sources"""
        results = []
        
        # APKMirror search
        try:
            url = f"https://www.apkmirror.com/?post_type=app_release&searchtype=apk&s={urllib.parse.quote(query)}"
            r = self.fetch(url)
            if r["success"] and r.get("text"):
                text = r["text"]
                results.append({
                    "source": "APKMirror",
                    "url": url,
                    "note": "Open in browser to download"
                })
        except:
            pass

        # F-Droid (open source apps)
        try:
            api_url = f"https://search.f-droid.org/?q={urllib.parse.quote(query)}&lang=en"
            r = self.fetch(api_url)
            if r["success"]:
                results.append({
                    "source": "F-Droid",
                    "url": api_url,
                    "note": "Open source Android apps"
                })
        except:
            pass

        return {"success": True, "results": results, "query": query}

    def api_call(self, url, api_key, messages, model="gpt-4o", max_tokens=4096, system=None):
        """Generic AI API call (OpenAI compatible)"""
        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "messages": messages,
        }
        if system:
            payload["system"] = system

        headers = {
            "Authorization": f"Bearer {api_key}",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        }

        result = self.fetch(url, method="POST", json_data=payload, headers=headers)
        return result

    def call_ollama(self, prompt, model="llama3", url="http://localhost:11434"):
        """Call local Ollama instance"""
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
        }
        result = self.fetch(f"{url}/api/generate", method="POST", json_data=payload)
        if result["success"] and result.get("json"):
            return {"success": True, "text": result["json"].get("response", "")}
        return {"success": False, "error": result.get("error", "Ollama error")}
