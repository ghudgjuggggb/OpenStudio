#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tool Manager - Downloads and manages APK editing tools"""

import os
import subprocess
import shutil
from pathlib import Path

class ToolManager:
    
    TOOLS = {
        # APK tools
        "apktool":      {"type": "jar",    "desc": "APK decompile/recompile"},
        "jadx":         {"type": "binary", "desc": "Java decompiler"},
        "aapt":         {"type": "pkg",    "desc": "Android Asset Packaging Tool"},
        "aapt2":        {"type": "pkg",    "desc": "Android Asset Packaging Tool 2"},
        "zipalign":     {"type": "pkg",    "desc": "APK alignment"},
        "apksigner":    {"type": "pkg",    "desc": "APK signing"},
        # General tools
        "java":         {"type": "pkg",    "desc": "Java runtime"},
        "python":       {"type": "builtin","desc": "Python interpreter"},
        "curl":         {"type": "pkg",    "desc": "HTTP client"},
        "wget":         {"type": "pkg",    "desc": "File downloader"},
        "git":          {"type": "pkg",    "desc": "Version control"},
        "zip":          {"type": "pkg",    "desc": "Zip utility"},
        "unzip":        {"type": "pkg",    "desc": "Unzip utility"},
        "adb":          {"type": "pkg",    "desc": "Android Debug Bridge"},
        "nano":         {"type": "pkg",    "desc": "Text editor"},
        "grep":         {"type": "builtin","desc": "Text search"},
        "find":         {"type": "builtin","desc": "File finder"},
    }

    TERMUX_PKGS = {
        "java": "openjdk-21",
        "aapt": "aapt",
        "aapt2": "aapt2",
        "zipalign": "zipalign",
        "apksigner": "apksigner",
        "curl": "curl",
        "wget": "wget",
        "git": "git",
        "zip": "zip",
        "unzip": "unzip",
        "adb": "android-tools",
        "nano": "nano",
    }

    APKTOOL_URL = "https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.3.jar"
    JADX_URL = "https://github.com/skylot/jadx/releases/download/v1.5.0/jadx-1.5.0.zip"

    def __init__(self, ui):
        self.ui = ui
        self.home = Path.home()
        self.bin_dir = self.home / ".local" / "bin"
        self.tools_dir = self.home / ".apk_terminal_tools"
        self.bin_dir.mkdir(parents=True, exist_ok=True)
        self.tools_dir.mkdir(parents=True, exist_ok=True)

    def check_tool(self, name):
        """Check if a tool is installed"""
        result = shutil.which(name)
        if result:
            return True
        # Check our tools dir
        for f in [self.tools_dir / name, self.bin_dir / name]:
            if f.exists():
                return True
        return False

    def get_all_status(self):
        """Get status of all tools"""
        return {name: self.check_tool(name) for name in self.TOOLS}

    def check_and_install_all(self):
        """Check and install missing tools"""
        missing = [name for name in self.TOOLS if not self.check_tool(name) 
                   and self.TOOLS[name]["type"] not in ("builtin",)]
        
        if not missing:
            self.ui.success("All tools are installed!")
            return True

        self.ui.warn(f"Missing tools: {', '.join(missing)}")
        self.ui.info("Installing missing tools automatically...")

        # Check if we're in Termux
        in_termux = os.path.exists('/data/data/com.termux') or os.path.exists('/data/data/com.termux/files/usr')

        for name in missing:
            self.install_tool(name, in_termux)

        return True

    def install_tool(self, name, in_termux=True):
        """Install a single tool"""
        tool = self.TOOLS.get(name, {})
        ttype = tool.get("type", "pkg")

        self.ui.info(f"Installing {name}...")

        try:
            if ttype == "pkg" and in_termux:
                pkg = self.TERMUX_PKGS.get(name, name)
                result = subprocess.run(
                    ["pkg", "install", "-y", pkg],
                    capture_output=True, text=True, timeout=300
                )
                if result.returncode == 0:
                    self.ui.success(f"  ✔ {name} installed via pkg")
                    return True
                else:
                    # Try apt
                    result = subprocess.run(
                        ["apt-get", "install", "-y", pkg],
                        capture_output=True, text=True, timeout=300
                    )
                    if result.returncode == 0:
                        self.ui.success(f"  ✔ {name} installed via apt")
                        return True

            elif ttype == "jar":
                return self._install_apktool()
            
            elif ttype == "binary":
                if name == "jadx":
                    return self._install_jadx()

            elif ttype == "pkg" and not in_termux:
                # Try pip or other methods on non-Termux
                self.ui.warn(f"  ⚠ {name} requires Termux package manager. Install manually.")
                return False

        except subprocess.TimeoutExpired:
            self.ui.error(f"  ✘ Timeout installing {name}")
        except Exception as e:
            self.ui.error(f"  ✘ Error installing {name}: {e}")
        
        return False

    def _install_apktool(self):
        """Download and install apktool"""
        try:
            jar_path = self.tools_dir / "apktool.jar"
            wrapper_path = self.bin_dir / "apktool"

            if not jar_path.exists():
                self.ui.info("  Downloading apktool...")
                result = subprocess.run(
                    ["curl", "-L", "-o", str(jar_path), self.APKTOOL_URL],
                    capture_output=True, timeout=120
                )
                if result.returncode != 0:
                    # Try wget
                    subprocess.run(
                        ["wget", "-O", str(jar_path), self.APKTOOL_URL],
                        capture_output=True, timeout=120
                    )

            # Create wrapper script
            wrapper_content = f"""#!/bin/bash
java -jar {jar_path} "$@"
"""
            with open(wrapper_path, 'w') as f:
                f.write(wrapper_content)
            os.chmod(wrapper_path, 0o755)
            
            self.ui.success("  ✔ apktool installed")
            return True
        except Exception as e:
            self.ui.error(f"  ✘ apktool install failed: {e}")
            return False

    def _install_jadx(self):
        """Download and install jadx"""
        try:
            jadx_dir = self.tools_dir / "jadx"
            jadx_zip = self.tools_dir / "jadx.zip"
            
            if not jadx_dir.exists():
                self.ui.info("  Downloading jadx...")
                subprocess.run(
                    ["curl", "-L", "-o", str(jadx_zip), self.JADX_URL],
                    capture_output=True, timeout=180
                )
                jadx_dir.mkdir(exist_ok=True)
                subprocess.run(
                    ["unzip", "-q", str(jadx_zip), "-d", str(jadx_dir)],
                    capture_output=True
                )
                jadx_zip.unlink(missing_ok=True)

            # Create wrapper
            jadx_bin = list(jadx_dir.glob("**/jadx"))
            if jadx_bin:
                wrapper = self.bin_dir / "jadx"
                wrapper.write_text(f'#!/bin/bash\n{jadx_bin[0]} "$@"\n')
                os.chmod(wrapper, 0o755)
                self.ui.success("  ✔ jadx installed")
                return True

        except Exception as e:
            self.ui.error(f"  ✘ jadx install failed: {e}")
        return False

    def run_tool(self, tool, args, cwd=None, timeout=120):
        """Run a tool and return output"""
        cmd = [tool] + (args if isinstance(args, list) else args.split())
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=timeout,
                env={**os.environ, "PATH": f"{self.bin_dir}:{os.environ.get('PATH', '')}"}
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": f"Timeout after {timeout}s", "returncode": -1}
        except FileNotFoundError:
            return {"success": False, "stdout": "", "stderr": f"Tool '{tool}' not found", "returncode": -1}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}

    def run_shell(self, command, cwd=None, timeout=60):
        """Run arbitrary shell command"""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=timeout,
                env={**os.environ, "PATH": f"{self.bin_dir}:{os.environ.get('PATH', '')}"}
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "output": result.stdout + (("\n" + result.stderr) if result.stderr else "")
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": f"Timeout", "returncode": -1, "output": "Timeout"}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1, "output": str(e)}
