#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""APK Engine - Core APK manipulation and editing"""

import os
import shutil
import zipfile
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime


class APKEngine:
    
    def __init__(self, ui, tool_manager):
        self.ui = ui
        self.tm = tool_manager
        self.work_dir = Path.home() / "apk_workspace"
        self.work_dir.mkdir(parents=True, exist_ok=True)

    def _ensure_abs(self, path):
        p = Path(path)
        if not p.is_absolute():
            p = Path.cwd() / p
        return p.resolve()

    def decompile(self, apk_path, out_dir=None, options=""):
        """Decompile APK using apktool"""
        apk = self._ensure_abs(apk_path)
        if not apk.exists():
            return {"success": False, "error": f"APK not found: {apk}"}

        if out_dir is None:
            out_dir = self.work_dir / (apk.stem + "_decompiled")
        else:
            out_dir = Path(out_dir)

        if out_dir.exists():
            shutil.rmtree(out_dir)

        self.ui.info(f"Decompiling {apk.name} → {out_dir}")

        args = ["d", str(apk), "-o", str(out_dir), "--no-crunch", "-f"]
        if options:
            args.extend(options.split())

        result = self.tm.run_tool("apktool", args, timeout=180)
        
        if result["success"]:
            self.ui.success(f"Decompiled to: {out_dir}")
            return {"success": True, "out_dir": str(out_dir), "output": result["stdout"]}
        else:
            # Try basic unzip fallback
            self.ui.warn("apktool failed, trying zip extraction...")
            return self._extract_zip(apk, out_dir)

    def compile(self, src_dir, out_apk=None, options=""):
        """Compile directory back to APK"""
        src = self._ensure_abs(src_dir)
        if not src.exists():
            return {"success": False, "error": f"Directory not found: {src}"}

        if out_apk is None:
            out_apk = self.work_dir / (src.name.replace("_decompiled", "") + "_recompiled.apk")
        
        self.ui.info(f"Compiling {src.name} → {out_apk.name}")

        args = ["b", str(src), "-o", str(out_apk)]
        if options:
            args.extend(options.split())

        result = self.tm.run_tool("apktool", args, timeout=300)
        
        if result["success"] and Path(out_apk).exists():
            self.ui.success(f"Compiled: {out_apk}")
            return {"success": True, "apk_path": str(out_apk), "output": result["stdout"]}
        else:
            return {"success": False, "error": result["stderr"], "output": result["stdout"] + result["stderr"]}

    def sign(self, apk_path, out_path=None, keystore=None, alias="androiddebugkey", key_pass="android"):
        """Sign APK with debug key or custom keystore"""
        apk = self._ensure_abs(apk_path)
        if not apk.exists():
            return {"success": False, "error": f"APK not found: {apk}"}

        if out_path is None:
            out_path = apk.parent / (apk.stem + "_signed.apk")

        # First zipalign
        self.ui.info("Running zipalign...")
        aligned = str(out_path).replace(".apk", "_aligned.apk")
        align_result = self.tm.run_tool("zipalign", ["-v", "-p", "4", str(apk), aligned])
        
        if not align_result["success"]:
            aligned = str(apk)  # fallback to original

        # Create debug keystore if needed
        if keystore is None:
            keystore = self._ensure_debug_keystore()

        # Sign with apksigner
        self.ui.info("Signing APK...")
        sign_result = self.tm.run_tool("apksigner", [
            "sign",
            "--ks", str(keystore),
            "--ks-pass", f"pass:{key_pass}",
            "--ks-key-alias", alias,
            "--out", str(out_path),
            aligned
        ])

        # Cleanup aligned temp
        if aligned != str(apk) and Path(aligned).exists():
            Path(aligned).unlink()

        if sign_result["success"]:
            self.ui.success(f"Signed APK: {out_path}")
            return {"success": True, "signed_apk": str(out_path)}
        else:
            # Fallback: jarsigner
            return self._sign_jarsigner(apk, out_path, keystore, alias, key_pass)

    def _sign_jarsigner(self, apk, out_path, keystore, alias, key_pass):
        result = self.tm.run_tool("jarsigner", [
            "-keystore", str(keystore),
            "-storepass", key_pass,
            "-keypass", key_pass,
            "-signedjar", str(out_path),
            str(apk), alias
        ])
        if result["success"]:
            self.ui.success(f"Signed with jarsigner: {out_path}")
            return {"success": True, "signed_apk": str(out_path)}
        return {"success": False, "error": result["stderr"]}

    def _ensure_debug_keystore(self):
        """Create debug keystore if not exists"""
        ks_dir = Path.home() / ".config" / "apk_terminal"
        ks_dir.mkdir(parents=True, exist_ok=True)
        ks_path = ks_dir / "debug.keystore"
        
        if not ks_path.exists():
            self.ui.info("Creating debug keystore...")
            result = self.tm.run_tool("keytool", [
                "-genkey", "-v",
                "-keystore", str(ks_path),
                "-storepass", "android",
                "-alias", "androiddebugkey",
                "-keypass", "android",
                "-keyalg", "RSA",
                "-keysize", "2048",
                "-validity", "10000",
                "-dname", "CN=Android Debug,O=Android,C=US"
            ])
        
        return ks_path

    def get_info(self, apk_path):
        """Get APK information"""
        apk = self._ensure_abs(apk_path)
        if not apk.exists():
            return {"success": False, "error": f"APK not found: {apk}"}

        info = {
            "file": str(apk),
            "size": apk.stat().st_size,
            "size_mb": round(apk.stat().st_size / 1024 / 1024, 2),
        }

        # aapt info
        aapt_result = self.tm.run_tool("aapt", ["dump", "badging", str(apk)])
        if aapt_result["success"]:
            info["aapt"] = self._parse_aapt(aapt_result["stdout"])
        
        # aapt2 dump
        aapt2_result = self.tm.run_tool("aapt2", ["dump", "badging", str(apk)])
        if aapt2_result["success"] and "aapt" not in info:
            info["aapt2"] = aapt2_result["stdout"][:2000]

        # List contents
        try:
            with zipfile.ZipFile(apk, 'r') as zf:
                files = zf.namelist()
                info["files_count"] = len(files)
                info["has_dex"] = any(f.endswith('.dex') for f in files)
                info["dex_count"] = sum(1 for f in files if f.endswith('.dex'))
                info["has_libs"] = any(f.startswith('lib/') for f in files)
                info["libs"] = list(set(f.split('/')[1] for f in files if f.startswith('lib/')))
                info["has_kotlin"] = any('kotlin' in f.lower() for f in files)
        except Exception as e:
            info["zip_error"] = str(e)

        # Read manifest from extracted
        manifest = self._quick_manifest(apk)
        if manifest:
            info["manifest"] = manifest

        return {"success": True, "info": info}

    def _quick_manifest(self, apk):
        """Try to extract manifest info quickly"""
        try:
            with zipfile.ZipFile(apk, 'r') as zf:
                if 'AndroidManifest.xml' in zf.namelist():
                    data = zf.read('AndroidManifest.xml')
                    # Binary XML - try aapt
                    result = self.tm.run_tool("aapt", ["dump", "xmltree", str(apk), "AndroidManifest.xml"])
                    if result["success"]:
                        return result["stdout"][:3000]
        except:
            pass
        return None

    def _parse_aapt(self, output):
        """Parse aapt badging output"""
        info = {}
        for line in output.split('\n'):
            if line.startswith("package:"):
                info["package_line"] = line
            elif line.startswith("sdkVersion:"):
                info["min_sdk"] = line.split("'")[1] if "'" in line else ""
            elif line.startswith("targetSdkVersion:"):
                info["target_sdk"] = line.split("'")[1] if "'" in line else ""
            elif line.startswith("application-label:"):
                info["label"] = line.split("'")[1] if "'" in line else ""
            elif line.startswith("uses-permission:"):
                if "permissions" not in info:
                    info["permissions"] = []
                perm = line.split("'")[1] if "'" in line else line
                info["permissions"].append(perm)
        return info

    def _extract_zip(self, apk, out_dir):
        """Basic zip extraction fallback"""
        try:
            out_dir = Path(out_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(apk, 'r') as zf:
                zf.extractall(out_dir)
            self.ui.success(f"Extracted (basic mode) to: {out_dir}")
            return {"success": True, "out_dir": str(out_dir), "note": "Basic extraction without decompile"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def read_manifest(self, apk_or_dir):
        """Read AndroidManifest.xml"""
        p = self._ensure_abs(apk_or_dir)
        
        # If it's a decompiled dir
        manifest_file = p / "AndroidManifest.xml" if p.is_dir() else None
        
        if manifest_file and manifest_file.exists():
            return {"success": True, "content": manifest_file.read_text(errors='replace'), "path": str(manifest_file)}
        
        # If it's an APK - use aapt
        if p.suffix.lower() == '.apk':
            result = self.tm.run_tool("aapt", ["dump", "xmltree", str(p), "AndroidManifest.xml"])
            if result["success"]:
                return {"success": True, "content": result["stdout"], "note": "Binary XML via aapt"}
            
            # Try extracting
            extract_result = self.decompile(p)
            if extract_result["success"]:
                mf = Path(extract_result["out_dir"]) / "AndroidManifest.xml"
                if mf.exists():
                    return {"success": True, "content": mf.read_text(), "path": str(mf)}
        
        return {"success": False, "error": "Could not read manifest"}

    def write_manifest(self, dir_path, content):
        """Write AndroidManifest.xml to decompiled dir"""
        p = self._ensure_abs(dir_path)
        mf = p / "AndroidManifest.xml"
        try:
            mf.write_text(content)
            return {"success": True, "path": str(mf)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def find_smali(self, dir_path, search_term=None):
        """Find smali files"""
        p = self._ensure_abs(dir_path)
        smali_files = list(p.rglob("*.smali"))
        
        if search_term:
            matches = []
            for sf in smali_files:
                try:
                    if search_term.lower() in sf.read_text(errors='ignore').lower():
                        matches.append(str(sf))
                except:
                    pass
            return {"success": True, "files": matches, "count": len(matches)}
        
        return {"success": True, "files": [str(f) for f in smali_files], "count": len(smali_files)}

    def patch_file(self, file_path, old_content, new_content):
        """Patch a file by replacing content"""
        p = self._ensure_abs(file_path)
        try:
            content = p.read_text(errors='replace')
            if old_content not in content:
                return {"success": False, "error": "Pattern not found in file"}
            
            # Backup
            backup = str(p) + ".bak"
            p.write_bytes(p.read_bytes())
            shutil.copy2(p, backup)
            
            new = content.replace(old_content, new_content)
            p.write_text(new)
            return {"success": True, "replaced": content.count(old_content), "backup": backup}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def list_resources(self, dir_path):
        """List APK resources"""
        p = self._ensure_abs(dir_path)
        res_dir = p / "res"
        
        if not res_dir.exists():
            return {"success": False, "error": "No res/ directory found"}
        
        resources = {}
        for item in res_dir.iterdir():
            if item.is_dir():
                files = [f.name for f in item.iterdir()]
                resources[item.name] = files[:20]  # limit

        return {"success": True, "resources": resources, "path": str(res_dir)}

    def backup_apk(self, apk_path):
        """Create backup of APK"""
        apk = self._ensure_abs(apk_path)
        backup_dir = Path.home() / "apk_backups"
        backup_dir.mkdir(exist_ok=True)
        
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = backup_dir / f"{apk.stem}_{ts}.apk"
        shutil.copy2(apk, backup)
        return {"success": True, "backup": str(backup)}

    def install_apk(self, apk_path):
        """Install APK via adb"""
        apk = self._ensure_abs(apk_path)
        result = self.tm.run_tool("adb", ["install", "-r", str(apk)])
        if result["success"] or "Success" in result["stdout"]:
            return {"success": True, "output": result["stdout"]}
        
        # Try via pm install
        result2 = self.tm.run_shell(f"pm install -r {apk}")
        return {"success": result2["success"], "output": result2["output"]}

    def decompile_java(self, apk_path, out_dir=None):
        """Decompile to Java using jadx"""
        apk = self._ensure_abs(apk_path)
        if out_dir is None:
            out_dir = self.work_dir / (apk.stem + "_java")
        
        self.ui.info(f"Decompiling to Java with jadx...")
        result = self.tm.run_tool("jadx", [
            "--output-dir", str(out_dir),
            "--threads-count", "4",
            str(apk)
        ], timeout=300)
        
        if result["success"]:
            return {"success": True, "out_dir": str(out_dir)}
        return {"success": False, "error": result["stderr"]}
