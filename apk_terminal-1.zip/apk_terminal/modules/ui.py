#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Terminal UI with colors and formatting"""

import os
import sys
import shutil
from datetime import datetime

class Colors:
    # Basic
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    ITALIC = '\033[3m'
    UNDERLINE = '\033[4m'
    
    # Foreground
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Bright
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    
    # Background
    BG_BLACK = '\033[40m'
    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_BLUE = '\033[44m'
    BG_CYAN = '\033[46m'
    BG_WHITE = '\033[47m'

C = Colors()

class UI:
    def __init__(self):
        self.width = self._get_width()
        self.no_color = not sys.stdout.isatty() or os.environ.get('NO_COLOR')

    def _get_width(self):
        try:
            return shutil.get_terminal_size().columns
        except:
            return 80

    def _c(self, *codes):
        if self.no_color:
            return ''
        return ''.join(codes)

    def clear_screen(self):
        os.system('clear' if os.name != 'nt' else 'cls')

    def print_banner(self):
        w = min(self.width, 70)
        banner = f"""
{self._c(C.BRIGHT_GREEN, C.BOLD)}{'█' * w}
█{'':^{w-2}}█
█{'  ▄▄  ██████  ██  ██    ████████ ███████ ██████  ██   ██ ██ ███    ██  █  ██   '.center(w-2)}█
█{'  ██  ██   ██ ██  ██       ██    ██      ██   ██ ███ ███ ██ ████   ██  ██ ██   '.center(w-2)}█
█{'  ██  ██████  ██████       ██    █████   ██████  ██ █ ██ ██ ██ ██  ██  ████   '.center(w-2)}█
█{'  ██  ██      ██  ██       ██    ██      ██   ██ ██   ██ ██ ██  ██ ██  ██ ██  '.center(w-2)}█
█{'  ██  ██      ██  ██       ██    ███████ ██   ██ ██   ██ ██ ██   ████  ██  ██ '.center(w-2)}█
█{'':^{w-2}}█
█{'  AI-Powered APK Editor for Termux  v1.0.0'.center(w-2)}█
█{'  Full File Access  |  Internet  |  APK Tools'.center(w-2)}█
█{'':^{w-2}}█
{'█' * w}{self._c(C.RESET)}
"""
        print(banner)

    def print_separator(self, char='─', color=None):
        w = min(self.width, 70)
        col = color or self._c(C.DIM, C.CYAN)
        print(f"{col}{char * w}{self._c(C.RESET)}")

    def info(self, msg):
        ts = datetime.now().strftime('%H:%M:%S')
        print(f"{self._c(C.DIM)}[{ts}]{self._c(C.RESET)} {self._c(C.BRIGHT_CYAN)}ℹ{self._c(C.RESET)}  {msg}")

    def success(self, msg):
        ts = datetime.now().strftime('%H:%M:%S')
        print(f"{self._c(C.DIM)}[{ts}]{self._c(C.RESET)} {self._c(C.BRIGHT_GREEN)}✔{self._c(C.RESET)}  {msg}")

    def warn(self, msg):
        ts = datetime.now().strftime('%H:%M:%S')
        print(f"{self._c(C.DIM)}[{ts}]{self._c(C.RESET)} {self._c(C.BRIGHT_YELLOW)}⚠{self._c(C.RESET)}  {msg}")

    def error(self, msg):
        ts = datetime.now().strftime('%H:%M:%S')
        print(f"{self._c(C.DIM)}[{ts}]{self._c(C.RESET)} {self._c(C.BRIGHT_RED)}✘{self._c(C.RESET)}  {msg}")

    def ai_msg(self, msg):
        """Print AI response"""
        print(f"\n{self._c(C.BRIGHT_GREEN, C.BOLD)}🤖 AI ›{self._c(C.RESET)} {msg}\n")

    def tool_output(self, tool, output, success=True):
        """Print tool execution output"""
        icon = '✔' if success else '✘'
        color = C.BRIGHT_GREEN if success else C.BRIGHT_RED
        print(f"\n{self._c(C.DIM)}┌─ Tool: {tool} {icon}{self._c(C.RESET)}")
        for line in str(output).strip().split('\n'):
            print(f"{self._c(C.DIM)}│{self._c(C.RESET)} {line}")
        print(f"{self._c(C.DIM)}└{'─' * 40}{self._c(C.RESET)}")

    def prompt(self):
        """Get user input with styled prompt"""
        try:
            user_input = input(f"\n{self._c(C.BRIGHT_MAGENTA, C.BOLD)}you ›{self._c(C.RESET)} ").strip()
            return user_input
        except (EOFError, KeyboardInterrupt):
            print()
            return '/exit'

    def print_help(self):
        """Print help menu"""
        self.print_separator('═')
        print(f"\n{self._c(C.BRIGHT_CYAN, C.BOLD)}📚 APK TERMINAL - Commands{self._c(C.RESET)}\n")
        
        sections = [
            ("APK Commands", [
                ("/decompile <apk>",    "Decompile APK with apktool"),
                ("/compile <dir>",      "Compile APK from directory"),
                ("/sign <apk>",         "Sign APK with debug key"),
                ("/info <apk>",         "Show APK info (manifest, permissions)"),
                ("/extract <apk>",      "Extract APK contents"),
                ("/patch <apk>",        "AI-assisted APK patching"),
                ("/smali <apk>",        "View/edit SMALI code"),
                ("/manifest <apk>",     "Edit AndroidManifest.xml"),
                ("/resources <apk>",    "Edit APK resources"),
                ("/optimize <apk>",     "Optimize APK (zipalign)"),
                ("/install <apk>",      "Install APK via adb"),
            ]),
            ("File Commands", [
                ("/ls [path]",          "List files"),
                ("/cd <path>",          "Change directory"),
                ("/cat <file>",         "View file content"),
                ("/edit <file>",        "Edit file with AI"),
                ("/find <name>",        "Find files"),
                ("/download <url>",     "Download file"),
                ("/upload",             "Upload file info"),
            ]),
            ("Tools Commands", [
                ("/tools",              "List available tools"),
                ("/install-tools",      "Install all required tools"),
                ("/update-tools",       "Update all tools"),
                ("/shell <cmd>",        "Execute shell command"),
            ]),
            ("Settings", [
                ("/config",             "Show/edit settings"),
                ("/setkey <key>",       "Set AI API key"),
                ("/model <name>",       "Change AI model"),
                ("/history",            "Show conversation history"),
                ("/clear",              "Clear screen"),
                ("/help",               "Show this help"),
                ("/exit",               "Exit APK Terminal"),
            ]),
        ]
        
        for section_name, commands in sections:
            print(f"  {self._c(C.BRIGHT_YELLOW, C.BOLD)}{section_name}:{self._c(C.RESET)}")
            for cmd, desc in commands:
                print(f"    {self._c(C.BRIGHT_GREEN)}{cmd:<28}{self._c(C.RESET)}{self._c(C.DIM)}{desc}{self._c(C.RESET)}")
            print()
        
        print(f"  {self._c(C.DIM)}💡 Or just type anything in natural language and AI will handle it!{self._c(C.RESET)}\n")
        self.print_separator('═')

    def print_tools_table(self, tools_status):
        """Print tools installation status table"""
        self.print_separator()
        print(f"\n{self._c(C.BRIGHT_CYAN, C.BOLD)}🛠  Tool Status:{self._c(C.RESET)}\n")
        for tool, installed in tools_status.items():
            status = f"{self._c(C.BRIGHT_GREEN)}✔ installed{self._c(C.RESET)}" if installed else f"{self._c(C.BRIGHT_RED)}✘ missing{self._c(C.RESET)}"
            print(f"  {tool:<20} {status}")
        print()
        self.print_separator()

    def spinner(self, message, func, *args, **kwargs):
        """Run function with spinner animation"""
        import itertools
        spinner_chars = itertools.cycle(['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'])
        result = [None]
        error = [None]
        done = [False]

        def run():
            try:
                result[0] = func(*args, **kwargs)
            except Exception as e:
                error[0] = e
            finally:
                done[0] = True

        t = threading.Thread(target=run)
        t.start()

        while not done[0]:
            char = next(spinner_chars)
            print(f"\r{self._c(C.BRIGHT_CYAN)}{char}{self._c(C.RESET)} {message}...", end='', flush=True)
            time.sleep(0.1)

        print(f"\r{'':60}\r", end='')  # clear spinner line
        
        if error[0]:
            raise error[0]
        return result[0]

import threading
import time
