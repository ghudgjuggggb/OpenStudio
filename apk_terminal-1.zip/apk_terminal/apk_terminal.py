#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔═══════════════════════════════════════════════════════════════╗
║              APK TERMINAL - AI Agent for Termux               ║
║         Full APK Editing + File System + Internet Access       ║
╚═══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import time
import subprocess
import threading
from pathlib import Path

# Add modules to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules.ui import UI
from modules.ai_agent import AIAgent
from modules.tool_manager import ToolManager
from modules.file_manager import FileManager
from modules.apk_engine import APKEngine
from modules.net_manager import NetManager
from config.settings import Settings

def check_termux():
    """Check if running in Termux"""
    return os.path.exists('/data/data/com.termux') or 'TERMUX_VERSION' in os.environ or os.path.exists('/data/data/com.termux/files/usr')

def main():
    ui = UI()
    ui.clear_screen()
    ui.print_banner()

    settings = Settings()
    
    if not check_termux():
        ui.warn("⚠  Not running in Termux. Some features may be limited.")
        ui.warn("   For full functionality, run on Android/Termux.")
        time.sleep(1)

    ui.info("🔧 Initializing APK Terminal...")
    
    # Initialize all modules
    tool_manager = ToolManager(ui)
    file_manager = FileManager(ui)
    apk_engine = APKEngine(ui, tool_manager)
    net_manager = NetManager(ui)
    
    # Check & install required tools
    ui.info("🔍 Checking required tools...")
    tool_manager.check_and_install_all()
    
    # Initialize AI Agent
    ui.info("🤖 Starting AI Agent...")
    agent = AIAgent(
        ui=ui,
        tool_manager=tool_manager,
        file_manager=file_manager,
        apk_engine=apk_engine,
        net_manager=net_manager,
        settings=settings
    )
    
    ui.success("✅ APK Terminal ready! Type 'help' for commands or ask the AI anything.")
    ui.print_separator()
    
    # Main loop
    agent.run()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 APK Terminal exited. Goodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
