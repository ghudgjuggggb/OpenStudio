#!/bin/bash
# ╔═══════════════════════════════════════════════════════╗
# ║          APK Terminal - Termux Installer              ║
# ║     AI-Powered APK Editor for Android/Termux          ║
# ╚═══════════════════════════════════════════════════════╝

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

info()    { echo -e "${CYAN}[INFO]${RESET} $1"; }
success() { echo -e "${GREEN}[OK]${RESET}   $1"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET} $1"; }
error()   { echo -e "${RED}[ERR]${RESET}  $1"; exit 1; }

echo -e "${GREEN}${BOLD}"
echo "  ┌──────────────────────────────────────┐"
echo "  │      APK Terminal Installer v1.0      │"
echo "  │   AI-Powered APK Editor for Termux    │"
echo "  └──────────────────────────────────────┘"
echo -e "${RESET}"

# Check Termux
if [ -d "/data/data/com.termux" ] || [ -n "$TERMUX_VERSION" ]; then
    info "Termux detected ✔"
    IS_TERMUX=true
else
    warn "Not running in Termux. Some features may be limited."
    IS_TERMUX=false
fi

# Install directory
INSTALL_DIR="$HOME/apk_terminal"
BIN_DIR="$HOME/.local/bin"
mkdir -p "$BIN_DIR"

info "Installing to: $INSTALL_DIR"

# Update package list
if [ "$IS_TERMUX" = true ]; then
    info "Updating Termux packages..."
    pkg update -y 2>/dev/null || apt-get update -y 2>/dev/null || true

    info "Installing required packages..."
    
    # Core packages
    PACKAGES="python openjdk-21 aapt aapt2 zipalign apksigner curl wget git zip unzip nano android-tools"
    
    for pkg in $PACKAGES; do
        info "  Installing $pkg..."
        pkg install -y "$pkg" 2>/dev/null || apt-get install -y "$pkg" 2>/dev/null || warn "  Could not install $pkg (may not be available)"
    done
    
    success "Base packages installed"
fi

# Install Python dependencies
info "Installing Python dependencies..."
pip install --quiet requests 2>/dev/null || pip3 install --quiet requests 2>/dev/null || true
success "Python deps ready"

# Copy APK Terminal files
info "Copying APK Terminal files..."
if [ -d "$INSTALL_DIR" ]; then
    warn "Directory exists, backing up..."
    mv "$INSTALL_DIR" "${INSTALL_DIR}_backup_$(date +%s)" 2>/dev/null || true
fi

# Copy from current directory or script location
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR" "$INSTALL_DIR" 2>/dev/null || {
    mkdir -p "$INSTALL_DIR"
    cp -r . "$INSTALL_DIR/" 2>/dev/null || true
}

# Install apktool if not present
if ! command -v apktool &>/dev/null; then
    info "Installing apktool..."
    TOOLS_DIR="$HOME/.apk_terminal_tools"
    mkdir -p "$TOOLS_DIR"
    
    APKTOOL_JAR="$TOOLS_DIR/apktool.jar"
    APKTOOL_URL="https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.9.3.jar"
    
    if curl -L -o "$APKTOOL_JAR" "$APKTOOL_URL" --progress-bar 2>/dev/null; then
        # Create wrapper
        cat > "$BIN_DIR/apktool" << 'EOF'
#!/bin/bash
TOOLS_DIR="$HOME/.apk_terminal_tools"
exec java -jar "$TOOLS_DIR/apktool.jar" "$@"
EOF
        chmod +x "$BIN_DIR/apktool"
        success "apktool installed"
    else
        warn "Could not download apktool. Install manually later."
    fi
fi

# Install jadx if not present
if ! command -v jadx &>/dev/null; then
    info "Installing jadx..."
    TOOLS_DIR="$HOME/.apk_terminal_tools"
    JADX_ZIP="$TOOLS_DIR/jadx.zip"
    JADX_DIR="$TOOLS_DIR/jadx"
    JADX_URL="https://github.com/skylot/jadx/releases/download/v1.5.0/jadx-1.5.0.zip"
    
    if curl -L -o "$JADX_ZIP" "$JADX_URL" --progress-bar 2>/dev/null; then
        mkdir -p "$JADX_DIR"
        unzip -q "$JADX_ZIP" -d "$JADX_DIR" 2>/dev/null
        rm -f "$JADX_ZIP"
        
        JADX_BIN=$(find "$JADX_DIR" -name "jadx" -type f 2>/dev/null | head -1)
        if [ -n "$JADX_BIN" ]; then
            chmod +x "$JADX_BIN"
            ln -sf "$JADX_BIN" "$BIN_DIR/jadx"
            success "jadx installed"
        fi
    else
        warn "Could not download jadx. Install manually later."
    fi
fi

# Create launcher script
info "Creating launcher..."
cat > "$BIN_DIR/apk-terminal" << LAUNCHER
#!/bin/bash
# APK Terminal Launcher
export PATH="\$HOME/.local/bin:\$PATH"
cd "\$HOME/apk_terminal"
exec python apk_terminal.py "\$@"
LAUNCHER

chmod +x "$BIN_DIR/apk-terminal"

# Also create short alias
cat > "$BIN_DIR/apkt" << LAUNCHER2
#!/bin/bash
exec apk-terminal "\$@"
LAUNCHER2
chmod +x "$BIN_DIR/apkt"

# Create workspace directories
info "Creating workspace..."
mkdir -p "$HOME/apk_workspace"
mkdir -p "$HOME/apk_backups"
mkdir -p "$HOME/Downloads"
mkdir -p "$HOME/.config/apk_terminal"

# Add to PATH in shell profiles
for PROFILE in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile"; do
    if [ -f "$PROFILE" ]; then
        if ! grep -q "\.local/bin" "$PROFILE" 2>/dev/null; then
            echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$PROFILE"
            info "Added ~/.local/bin to PATH in $PROFILE"
        fi
    fi
done

# Final check
echo ""
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════${RESET}"
echo -e "${GREEN}${BOLD}   ✅ APK Terminal installed successfully!   ${RESET}"
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════${RESET}"
echo ""
echo -e "  ${CYAN}How to run:${RESET}"
echo -e "    ${BOLD}apk-terminal${RESET}   or   ${BOLD}apkt${RESET}"
echo ""
echo -e "  ${CYAN}Quick start:${RESET}"
echo -e "    1. Start: ${BOLD}apkt${RESET}"
echo -e "    2. Set API key: ${BOLD}/setkey <your_openai_or_anthropic_key>${RESET}"
echo -e "    3. Or use Ollama: configure in ${BOLD}/config${RESET}"
echo -e "    4. Ask AI to edit any APK!"
echo ""
echo -e "  ${CYAN}Workspace:${RESET} ~/apk_workspace"
echo -e "  ${CYAN}Backups:${RESET}   ~/apk_backups"
echo ""

# Reload PATH hint
echo -e "  ${YELLOW}Run: source ~/.bashrc${RESET}  (to update PATH)"
echo -e "  ${YELLOW}Then: apkt${RESET}"
echo ""
